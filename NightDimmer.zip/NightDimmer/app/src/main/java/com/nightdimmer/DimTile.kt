package com.nightdimmer

import android.provider.Settings
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.content.Intent

class DimTile : TileService() {

    override fun onStartListening() {
        refresh()
    }

    override fun onClick() {
        if (OverlayService.running) {
            OverlayService.stop(this)
            qsTile?.state = Tile.STATE_INACTIVE
        } else if (Settings.canDrawOverlays(this)) {
            OverlayService.start(this)
            qsTile?.state = Tile.STATE_ACTIVE
        } else {
            val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivityAndCollapse(i)
        }
        qsTile?.updateTile()
    }

    private fun refresh() {
        qsTile?.apply {
            state = if (OverlayService.running) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
            label = "หรี่จอ"
            updateTile()
        }
    }
}
